base_words = ["kunal", "admin", "password", "welcome"]
years = ["2002", "2003", "2024"]
symbols = ["@", "#", "!"]

wordlist = []

for word in base_words:
    wordlist.append(word)
    wordlist.append(word.capitalize())
    for year in years:
        wordlist.append(word + year)
    for sym in symbols:
        wordlist.append(word + sym)

with open("custom_wordlist.txt", "w") as f:
    for w in wordlist:
        f.write(w + "\n")

print("Wordlist generated successfully!")




