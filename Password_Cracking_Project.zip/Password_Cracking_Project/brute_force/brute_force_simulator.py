import itertools
import string

length = 4
charset = string.ascii_lowercase

attempts = len(charset) ** length
print("Password length:", length)
print("Character set size:", len(charset))
print("Total combinations:", attempts)

speed = 100000  # attempts per second
time = attempts / speed

print("Estimated time (seconds):", time)
print("Estimated time (minutes):", time / 60)

