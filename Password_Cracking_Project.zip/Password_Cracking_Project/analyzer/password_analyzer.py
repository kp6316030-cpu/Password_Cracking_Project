import re

password = input("Enter password to analyze: ")

strength = "STRONG"
issues = []

if len(password) < 8:
    strength = "WEAK"
    issues.append("Too short")

if not re.search("[A-Z]", password):
    issues.append("No uppercase letter")

if not re.search("[a-z]", password):
    issues.append("No lowercase letter")

if not re.search("[0-9]", password):
    issues.append("No number")

if not re.search("[@#!$]", password):
    issues.append("No symbol")

print("\nPassword Strength:", strength)
if issues:
    print("Issues found:")
    for i in issues:
        print("-", i)
else:
    print("Good password!")
